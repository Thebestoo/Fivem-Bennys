ESX = nil
ESX = exports["es_extended"]:getSharedObject()
local chicken = vehicleBaseRepairCost

RegisterServerEvent('qb-bennys:attemptPurchase')
AddEventHandler('qb-bennys:attemptPurchase', function(type, upgradeLevel)
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    if type == "repair" then
        TriggerClientEvent('qb-bennys:purchaseSuccessful', source)
    elseif type == "performance" then
        TriggerClientEvent('qb-bennys:purchaseSuccessful', source)
    else
        TriggerClientEvent('qb-bennys:purchaseSuccessful', source)
    end
end)

RegisterServerEvent('qb-bennys:updateRepairCost')
AddEventHandler('qb-bennys:updateRepairCost', function(cost)
    chicken = cost
end)

RegisterServerEvent('updateVehicle')
AddEventHandler('updateVehicle', function(myCar)
    MySQL.Async.execute('UPDATE `owned_vehicles` SET `vehicle` = @vehicle WHERE `plate` = @plate',
	{
		['@plate']   = myCar.plate,
		['@vehicle'] = json.encode(myCar)
	})
end)